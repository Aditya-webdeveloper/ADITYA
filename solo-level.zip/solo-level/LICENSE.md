***Note of the author***

You can download another font here  
 <https://graphicriver.net/user/aphriellart/portfolio>  
   
 You can donate me at paypal  
 <esaprasetio@gmail.com>  
   
 Thank you!